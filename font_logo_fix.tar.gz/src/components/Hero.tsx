'use client'

import Image from 'next/image'
import { useState, useEffect } from 'react'

export default function Hero() {
  const [heroImage, setHeroImage] = useState('/hero-basbosa.jpg')

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.heroImage) {
          setHeroImage(data.heroImage)
        }
      })
  }, [])

  return (
    <section className="hero">
      <div className="container hero-content">
        <div className="hero-text">
          <h1>طعم الأصالة في كل قطعة</h1>
          <p>استمتع بألذ بسبوسة محشوة بالقرفة، محضرة بعناية لتناسب ذوقك الرفيع.</p>
          <button className="btn btn-primary" onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}>
            اطلب الآن
          </button>
        </div>
        <div className="hero-image">
          <img
            src={heroImage}
            alt="بسبوسة القرفة الفاخرة"
            style={{ width: '100%', height: 'auto', borderRadius: '16px' }}
          />
        </div>
      </div>

      <style jsx>{`
        .hero {
          padding: 4rem 0;
          background: linear-gradient(135deg, var(--bg) 0%, var(--white) 100%);
        }
        .hero-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 3rem;
          align-items: center;
        }
        .hero-text h1 {
          font-size: 3rem;
          color: var(--primary);
          margin-bottom: 1rem;
          font-weight: 800;
          line-height: 1.3;
        }
        .hero-text p {
          font-size: 1.25rem;
          color: var(--text);
          margin-bottom: 2rem;
          opacity: 0.85;
          line-height: 1.8;
        }
        
        @media (max-width: 768px) {
          .hero {
            padding: 2rem 0;
          }
          .hero-content {
            grid-template-columns: 1fr;
            text-align: center;
            gap: 1.5rem;
          }
          .hero-text h1 {
            font-size: 2rem;
          }
          .hero-text p {
            font-size: 1rem;
          }
          .hero-image {
            order: -1;
          }
        }
      `}</style>
    </section>
  )
}
