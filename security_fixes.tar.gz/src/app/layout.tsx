import type { Metadata } from 'next'
import { Inter, Outfit } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const outfit = Outfit({ subsets: ['latin'], variable: '--font-outfit' })

export const metadata: Metadata = {
  title: 'بسبوسة القرفة | Cinnamon Basbosa - أشهى البسبوسة في مكة',
  description: 'بسبوسة القرفة - أشهى بسبوسة محشوة بالقرفة في مكة المكرمة. اطلب الآن واستمتع بطعم الأصالة مع خدمة التوصيل.',
  keywords: 'بسبوسة, بسبوسة القرفة, حلويات مكة, توصيل حلويات, basbosa, cinnamon basbosa',
  openGraph: {
    title: 'بسبوسة القرفة | Cinnamon Basbosa',
    description: 'أشهى بسبوسة محشوة بالقرفة في مكة المكرمة. اطلب الآن!',
    type: 'website',
    locale: 'ar_SA',
  },
}

import { Providers } from '@/components/Providers'

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${inter.variable} ${outfit.variable}`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
