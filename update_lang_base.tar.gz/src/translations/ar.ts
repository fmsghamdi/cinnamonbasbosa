export const ar = {
    common: {
        language: 'English',
        darkMode: 'الوضع الليلي',
        lightMode: 'الوضع النهاري',
        myAccount: 'حسابي',
        adminDashboard: 'لوحة التحكم',
        cart: 'السلة',
    }
}
