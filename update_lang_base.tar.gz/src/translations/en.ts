export const en = {
    common: {
        language: 'عربي',
        darkMode: 'Dark Mode',
        lightMode: 'Light Mode',
        myAccount: 'My Account',
        adminDashboard: 'Admin Dashboard',
        cart: 'Cart',
    }
}
