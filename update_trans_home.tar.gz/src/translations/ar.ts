export const ar = {
    common: {
        language: 'English',
        darkMode: 'الوضع الليلي',
        lightMode: 'الوضع النهاري',
        myAccount: 'حسابي',
        adminDashboard: 'لوحة التحكم',
        cart: 'السلة',
    },
    hero: {
        title: 'طعم الأصالة في كل قطعة',
        subtitle: 'استمتع بألذ بسبوسة محشوة بالقرفة، محضرة بعناية لتناسب ذوقك الرفيع.',
        cta: 'اطلب الآن',
    },
    products: {
        title: 'منتجاتنا المميزة',
        subtitle: 'اختر من تشكيلتنا الفاخرة المحضرة بعناية',
        empty: 'لا توجد منتجات حالياً.',
        sortDefault: 'الترتيب الافتراضي',
        sortPriceLow: 'السعر: من الأقل',
        sortPriceHigh: 'السعر: من الأعلى',
        sortName: 'الاسم',
        count: 'منتج',
        addToCart: 'إضافة للسلة',
        added: '✓ تمت الإضافة',
        quickAdd: 'إضافة سريعة',
        optionsTitle: 'خيارات المنتج',
        optionsSubtitle: 'كيف تحب البسبوسة؟ 😋',
        withCinnamon: 'مع قرفة',
        withoutCinnamon: 'بدون قرفة',
        cancel: 'إلغاء'
    }
}
