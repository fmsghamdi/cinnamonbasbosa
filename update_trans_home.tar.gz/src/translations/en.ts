export const en = {
    common: {
        language: 'عربي',
        darkMode: 'Dark Mode',
        lightMode: 'Light Mode',
        myAccount: 'My Account',
        adminDashboard: 'Admin Dashboard',
        cart: 'Cart',
    },
    hero: {
        title: 'Authentic Taste in Every Bite',
        subtitle: 'Enjoy the most delicious cinnamon-stuffed basbosa, carefully prepared for your refined taste.',
        cta: 'Order Now',
    },
    products: {
        title: 'Our Premium Products',
        subtitle: 'Choose from our carefully prepared luxurious selection',
        empty: 'No products available currently.',
        sortDefault: 'Default Sorting',
        sortPriceLow: 'Price: Low to High',
        sortPriceHigh: 'Price: High to Low',
        sortName: 'Name',
        count: 'Products',
        addToCart: 'Add to Cart',
        added: '✓ Added',
        quickAdd: 'Quick Add',
        optionsTitle: 'Product Options',
        optionsSubtitle: 'How do you like your Basbosa? 😋',
        withCinnamon: 'With Cinnamon',
        withoutCinnamon: 'Without Cinnamon',
        cancel: 'Cancel'
    }
}
