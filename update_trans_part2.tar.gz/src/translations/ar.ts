export const ar = {
    common: {
        language: 'English',
        darkMode: 'الوضع الليلي',
        lightMode: 'الوضع النهاري',
        myAccount: 'حسابي',
        adminDashboard: 'لوحة التحكم',
        cart: 'السلة',
        currency: 'ر.س'
    },
    hero: {
        title: 'طعم الأصالة في كل قطعة',
        subtitle: 'استمتع بألذ بسبوسة محشوة بالقرفة، محضرة بعناية لتناسب ذوقك الرفيع.',
        cta: 'اطلب الآن',
    },
    products: {
        title: 'منتجاتنا المميزة',
        subtitle: 'اختر من تشكيلتنا الفاخرة المحضرة بعناية',
        empty: 'لا توجد منتجات حالياً.',
        sortDefault: 'الترتيب الافتراضي',
        sortPriceLow: 'السعر: من الأقل',
        sortPriceHigh: 'السعر: من الأعلى',
        sortName: 'الاسم',
        count: 'منتج',
        addToCart: 'إضافة للسلة',
        added: '✓ تمت الإضافة',
        quickAdd: 'إضافة سريعة',
        optionsTitle: 'خيارات المنتج',
        optionsSubtitle: 'كيف تحب البسبوسة؟ 😋',
        withCinnamon: 'مع قرفة',
        withoutCinnamon: 'بدون قرفة',
        cancel: 'إلغاء'
    },
    cartSection: {
        title: 'سلة التسوق',
        emptyTitle: 'سلتك فارغة!',
        emptySubtitle: 'أضف بعض السعادة ليومك 😋',
        browseBtn: 'تصفح القائمة',
        total: 'الإجمالي الكلي',
        checkout: 'إتمام الطلب'
    },
    gallery: {
        title: 'معرض الصور',
        subtitle: 'لحظات مميزة من مطبخنا'
    },
    footer: {
        desc: 'نقدم لكم أجود أنواع البسبوسة بالقرفة، محضرة بعناية فائقة من أفضل المكونات الطبيعية. نسعى لتقديم تجربة مميزة في كل قطعة.',
        quickLinks: 'روابط سريعة',
        home: 'الرئيسية',
        products: 'المنتجات',
        gallery: 'معرض الصور',
        contact: 'تواصل معنا',
        hours: 'يومياً من 8 صباحاً - 10 مساءً',
        country: 'المملكة العربية السعودية',
        rights: 'جميع الحقوق محفوظة.'
    }
}
