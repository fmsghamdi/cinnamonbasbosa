export const en = {
    common: {
        language: 'عربي',
        darkMode: 'Dark Mode',
        lightMode: 'Light Mode',
        myAccount: 'My Account',
        adminDashboard: 'Admin Dashboard',
        cart: 'Cart',
        currency: 'SAR'
    },
    hero: {
        title: 'Authentic Taste in Every Bite',
        subtitle: 'Enjoy the most delicious cinnamon-stuffed basbosa, carefully prepared for your refined taste.',
        cta: 'Order Now',
    },
    products: {
        title: 'Our Premium Products',
        subtitle: 'Choose from our carefully prepared luxurious selection',
        empty: 'No products available currently.',
        sortDefault: 'Default Sorting',
        sortPriceLow: 'Price: Low to High',
        sortPriceHigh: 'Price: High to Low',
        sortName: 'Name',
        count: 'Products',
        addToCart: 'Add to Cart',
        added: '✓ Added',
        quickAdd: 'Quick Add',
        optionsTitle: 'Product Options',
        optionsSubtitle: 'How do you like your Basbosa? 😋',
        withCinnamon: 'With Cinnamon',
        withoutCinnamon: 'Without Cinnamon',
        cancel: 'Cancel'
    },
    cartSection: {
        title: 'Shopping Cart',
        emptyTitle: 'Your cart is empty!',
        emptySubtitle: 'Add some happiness to your day 😋',
        browseBtn: 'Browse Menu',
        total: 'Total',
        checkout: 'Checkout'
    },
    gallery: {
        title: 'Gallery',
        subtitle: 'Special moments from our kitchen'
    },
    footer: {
        desc: 'We offer you the finest types of cinnamon basbosa, carefully prepared from the best natural ingredients. We strive to provide a unique experience in every bite.',
        quickLinks: 'Quick Links',
        home: 'Home',
        products: 'Products',
        gallery: 'Gallery',
        contact: 'Contact Us',
        hours: 'Daily from 8 AM - 10 PM',
        country: 'Saudi Arabia',
        rights: 'All rights reserved.'
    }
}
